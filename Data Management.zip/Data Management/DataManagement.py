# Jason Schwartz
# CINF 308: Programing For Informatics Assignment Twelve

# This imports the os.path module for checking if the user input file is in the same directory
import os.path

# This creates the data analyst list which I included outside the restart loop to allow users to interact with changes
DataPoints = []

# This establishes the FunctionChoice variable for later
FunctionChoice = 0

# This establishes the Continue variable for later
Continue = ""

# This establishes the ContinueOne variable for later
ContinueOne = ""

# This establishes the ContinueTwo variable for later
ContinueTwo = ""

# This establishes the SaveChoice variable for later
SaveChoice = ""

# This establishes the FileExists variable for later
FileExist = False

# This explains what the program will do
print("\nThis program will help data analysts easily manage and save their data through functions/algorithms")

# This loops the whole program if the user wants to restart
while True:

    # This breaks the loop to end the program
    if(FunctionChoice == 7):

        # This breaks the loop to end the program
        break

    # This breaks the loop to end the program
    if ContinueTwo == "no":

        # This breaks the loop to end the program
        break

    # This contains my Add algorithm
    def Add():

        # This loops to make sure the user input is valid
        while True:

            # This runs until an input is made that breaks the loop and doesn't cause an error
            try:

                # This displays the current data points for the user to see
                print("\nThese are the current data points:\n\n" + str(DataPoints))

                # This collects user input to manipulate the data points
                ListInput = int(input("\nPlease add an integer to the data points: "))

                # This adds the user input to the empty data points
                DataPoints.append(ListInput)

                # This prints out the reuslts
                print("\nThese are the new data points: \n\n" + str(DataPoints))

                # This asks the user if they want to start over and assigns their answer to a variable if it's accepted
                ContinueOne = input("\nWould you like to add more data points? (yes/no): ")

                # This checks if the user inputs was a valid response. If not it prints an error and loops in order to ask again
                while ContinueOne != "yes" and ContinueOne != "no":

                    # This prints out a result to the user and asks for input
                    ContinueOne = input("\nERROR: Please input: yes or no\n\nWould you like to add more data points? (yes/no): ")

                    # If the user input is valid the loop is broken
                    if ContinueOne == "yes" or ContinueOne == "no":

                        # This breaks the loop
                        break

                # This ends the loop/program if the user input:'no'. However, if they had input yes the main loop/program restarts
                if ContinueOne == "no":

                    # This breaks the loop
                    break

            # This makes sure the user put in an int and not a str
            except ValueError:

                # This prints out a result to the user
                print("\nERROR: Please enter an integer!")

    # This contains my Import algorithm
    def Import():

        # This loops to make sure the use input is valid before continuing
        while True:

                # This asks the user if they want to import a file
                Continue = input("\nWould you like to import data from a file? (yes/no): ")

                # This checks if the user inputs was a valid response. If not it prints an error and loops in order to ask again
                while Continue != "yes" and Continue != "no":

                    # This prints out a result to the user and asks for input
                    Continue = input("\nERROR: Please input: yes or no\n\nWould you like to import data from a file? (yes/no): ")

                    # If the user input is valid the loop is broken
                    if Continue == "yes" or Continue == "no":

                        # This breaks the loop
                        break

                # This allows the user to import a file if they said yes
                if Continue == "yes":

                    # This loops to make sure user input is correct
                    while True:

                        # This runs until an input is made that breaks the loop and doesn't cause an error
                        try:

                            # This allows the user to input a file name
                            FileName = input("\nPlease enter the name of the file (ex. Data.txt): ")

                            # This creates a File variable to open and read the user's file
                            File = open(FileName, 'r')

                            # This assigns the data from the user input file to a variable
                            DataImport = File.read()

                            # This loops to scan the imported data from the file and splits it
                            for x in DataImport.split():

                                # This checks if the value is an int and appends it to the data points if so
                                if x.isdigit():

                                    # This appends the int values to the data points
                                    DataPoints.append(int(x))

                            # This prints out the results
                            print("\nThese are the new data points:\n\n" + str(DataPoints))

                            # This checks if the data was empty
                            if (DataImport == ""):

                                # This prints out a result to the user
                                print("\nThere was no data!")
                            
                            # This breaks the loop
                            break

                        # This catches if the user put in an invalid file name
                        except IOError:

                            # This prints out a result to the user
                            print("\nPlease enter a valid file name (It has to be in the same directory)")
                
                # This breaks the loop
                if Continue == "yes":
                    
                    # This breaks the loop
                    break

                # This breaks the loop
                if Continue == "no":

                    # This runs the Add function
                    Add()

                    # This breaks the loop
                    break

    # This funtion contains my Search algorithm
    def Search():

        # This loops until the user inputs a valid data points value to search for
        while True:

            # This loops to makes sure that the user input is valid
            while True:

                # This runs until an input is made that breaks the loop and doesn't cause an error
                try:

                    # This displays the current data points for the user to see
                    print("\nThese are the current data points:\n\n" + str(DataPoints))

                    # This collects user input to manipulate the data points
                    UserInput = int(input("\nPlease enter an integer to search for in the data points: "))

                    # This breaks the loop if no error is caught
                    break

                # This makes sure the user put in an int and not a str
                except ValueError:

                    # This prints out a result to the user
                    print("\nERROR: Please enter an integer!")

            # This creates a boolean value to check if the user input was found in the data points or not
            InData = False

            # This loops through the data points to see if the user input was in the data points or not
            for x in DataPoints:

                # This checks if the user input was in the data points and prints/changes the boolean value if it is
                if (UserInput == x):

                    # This prints out the result
                    print("\n" + str(x) + " is in the data points!")

                    # This states that the value was indeed in the data points
                    InData = True

                    # This breaks the loop
                    break

            # This prints if the user input was not in the data points
            if (InData == False):

                # This prints out a result to the user
                print("\nSorry " + str(UserInput) + " is not in the data points")

            # This breaks the loop if the user input a valid data points value to search for
            if (InData == True):

                # This breaks the loop
                break

    # This contains my Sort algorithm
    def Sort():

        # This loops to makes sure that the user input is valid
        while True:

            # This runs until an input is made that breaks the loop and doesn't cause an error
            try:

                # This displays the current data points for the user to see
                print("\nThese are the current data points:\n\n" + str(DataPoints))

                # This collects user input to manipulate the data points
                UserInput = int(input("\nPlease enter what type of sort you would like to do:\n\n1. Ascending\n\n2. Descending\n\nEnter your choice here: "))

                # This makes sure that the user input is within the desired range and prints an error if it isn't and then asks again
                while (UserInput != 1 and UserInput != 2):

                    # This prints out a result to the user
                    print("\nERROR: Please enter the number associated with the type of sort you want!")

                    # This prints out a result to the user and asks for input
                    UserInput = int(input("\nPlease enter what type of sort you would like to do:\n\n1. Ascending\n\n2. Descending\n\nEnter your choice here: "))
                
                # This checks if the user input 1
                if(UserInput == 1):
                    
                    # This sorts the data points in ascending order
                    DataPoints.sort()

                    # This prints out the results
                    print("\nThese are the data points in ascending order:\n\n" + str(DataPoints))

                # This checks if the user input 2
                if(UserInput == 2):

                    # This sorts the data points in descending order
                    DataPoints.sort(reverse=True)

                    # This prints out the results
                    print("\nThese are the data points in descending order:\n\n" + str(DataPoints))

                # This breaks the loop if no error is caught
                break

            # This makes sure the user put in an int and not a str
            except ValueError:

                # This prints out a result to the user
                print("\nERROR: Please enter an integer!")

    # This contains my Insert algorithm
    def Insert():

        # This loops to makes sure that the user input is valid
        while True:

            # This runs until an input is made that breaks the loop and doesn't cause an error
            try:

                # This displays the current data points for the user to see
                print("\nThese are the current data points:\n\n" + str(DataPoints))

                # This collects user input to manipulate the data points
                UserInput = int(input("\nPlease enter an integer to insert into the data points: "))

                # This breaks the loop if no error is caught
                break

            # This makes sure the user put in an int and not a str
            except ValueError:

                # This prints out a result to the user
                print("\nERROR: Please enter an integer!")

        # This loops to makes sure that the user input is valid
        while True:

            # This runs until an input is made that breaks the loop and doesn't cause an error
            try:

                # This displays the current data points for the user to see
                print("\nThese are the current data points:\n\n" + str(DataPoints))

                # This lets the user know how many values are currently in the data points
                print("\nThere are currently " + str(len(DataPoints)) + " values inside the data points")

                # This collects user input to manipulate the data points
                IndexChoice = int(input("\nPlease enter at what value you want to input your number into the data points: "))
                
                # This makes sure that the user input is in the valid range and if not it prints an error and asks again (this accounts for DataPoints list starting at index 0 by adding one to the length range)
                while(IndexChoice > (len(DataPoints) + 1) or IndexChoice <= 0):

                    # This prints out a result to the user
                    print("\nERROR: The value must be within the size of the data points list")

                    # This prints out a result to the user and asks for input
                    IndexChoice = int(input("\nPlease enter at what value you want to input your number into the data points: "))

                # This accounts for data points starting at 0 by subtracting one from the user index choice
                IndexChoice -= 1

                # This adds 1 so the correction so the output is "normal" for the user
                IndexReport = IndexChoice + 1
                
                # This inserts the user input at their index choice in the data points with regards to some corrections accounting for the DataPoints list sstarting at index 0
                DataPoints.insert(IndexChoice, UserInput)

                # This prints the new data points with correct values for the user to understand
                print("\nThese are the new data points with your number: " + str(UserInput) +" at value: " + str(IndexReport) + ":" + "\n\n" + str(DataPoints))

                # This breaks the loop if no error is caught
                break
            
            # This makes sure the user put in an int and not a str
            except ValueError:

                # This prints out a result to the user
                print("\nERROR: Please enter an integer!")

    # This contains my Update algorithm
    def Update():

        # This loops until the user inputs a valid data points value to search for
        while True:

            # This loops to makes sure that the user input is valid
            while True:

                # This runs until an input is made that breaks the loop and doesn't cause an error
                try:

                    # This displays the current data points for the user to see
                    print("\nThese are the current data points:\n\n" + str(DataPoints))

                    # This collects user input to manipulate the data points
                    UserInput = int(input("\nPlease enter an integer to update from the data points: "))

                    # This breaks the loop if no error is caught
                    break

                # This makes sure the user put in an int and not a str
                except ValueError:

                    # This prints out a result to the user
                    print("\nERROR: Please enter an integer!")

            # This creates a boolean value to check if the user input was found in the data points or not
            InData = False

            # This loops through the data points to see if the user input was in the data points or not
            for x in DataPoints:

                # This checks if the user input was in the data points and prints/changes the boolean value if it is
                if (UserInput == x):

                    # This loops to makes sure that the user input is valid
                    while True:

                        # This runs until an input is made that breaks the loop and doesn't cause an error
                        try:

                            # This displays the current data points for the user to see
                            print("\nThese are the current data points:\n\n" + str(DataPoints))

                            # This collects user input to manipulate the data points
                            UserUpdateInput = int(input("\nPlease enter the new integer you want added to the data points instead: "))

                            # This breaks the loop if no error is caught
                            break

                        # This makes sure the user put in an int and not a str
                        except ValueError:

                            # This prints out a result to the user
                            print("\nERROR: Please enter an integer!")

                    # This obtains the index of the original non-updated user input value (from the data points list) and assigns it to a variable
                    IndexChoice = DataPoints.index(x)

                    # This removes the original non-updated value which was specifed by the user input
                    DataPoints.remove(UserInput)

                    # This inserts the new user input value at the index of the original non-updated value
                    DataPoints.insert(IndexChoice, UserUpdateInput)

                    # This prints out the result
                    print("\nThese are the new data points with your updated data:\n\n" + str(DataPoints))

                    # This states that the value was indeed in the data points
                    InData = True

                    # This breaks the loop
                    break

            # This prints if the user input was not in the data points
            if (InData == False):

                # This prints out a result to the user
                print("\nSorry " + str(UserInput) + " is not in the data points")

            # This breaks the loop if the user input a valid data points value to update
            if (InData == True):

                # This breaks the loop
                break

    # This contains my Delete algorithm
    def Delete():

        # This loops until the user inputs a valid data points value to delete
        while True:

            # This loops to makes sure that the user input is valid
            while True:

                # This runs until an input is made that breaks the loop and doesn't cause an error
                try:

                    # This displays the current data points for the user to see
                    print("\nThese are the current data points:\n\n" + str(DataPoints))
                    
                    # This collects user input to manipulate the data points
                    UserInput = int(input("\nPlease enter an integer to delete from the data points: "))

                    # This breaks the loop if no error is caught
                    break

                # This makes sure the user put in an int and not a str
                except ValueError:

                    # This prints out a result to the user
                    print("\nERROR: Please enter an integer!")

            # This creates a boolean value to check if the user input was found in the data points or not
            InData = False

            # This loops through the data points to see if the user input was in the data points or not
            for x in DataPoints:

                # This checks if the user input was in the data points and prints/changes the boolean value if it is
                if (UserInput == x):

                    # This deletes the value specified by the user
                    DataPoints.remove(UserInput)

                    # This prints out the result
                    print("\n" + str(UserInput) + " has been removed from the data points!\n\nThese are the new data points:\n\n" + str(DataPoints))

                    # This states that the value was indeed in the data points
                    InData = True

                    # This breaks the loop
                    break

            # This prints if the user input was not in the data points
            if (InData == False):
                print("\nSorry " + str(UserInput) + " is not in the data points")

            # This breaks the loop if the user input a valid data points value to delete
            if (InData == True):
                break

    # This breaks the loop to end the program
    if(FunctionChoice == 7):

        # This breaks the loop to end the program
        break

    # This loops to makes sure that the user input is valid
    while True:

        # This checks if the user has already run through the program. If not it starts the first time with the Add function
        if (ContinueTwo != "yes"):

            # This calls the Import function
            Import()

        # This runs until an input is made that breaks the loop and doesn't cause an error
        try: 

            # This obtains the users function choice
            FunctionChoice = int(input("\nPlease enter the number associated with the path you want to take: \n\n1. Search\n\n2. Sort\n\n3. Insert\n\n4. Update\n\n5. Delete\n\n6. Add\n\n7. Quit\n\nEnter your choice here: "))

            # This makes sure the user input is in the valid range and if not prints out an error and asks again
            while (FunctionChoice < 1 or FunctionChoice > 7):

                # This prints out a result to the user
                print("\nERROR: Please enter one of the algorithm numbers!")

                # This prints out a result to the user and asks for input
                FunctionChoice = int(input("\nPlease enter the number associated with the path you want to take: \n\n1. Search\n\n2. Sort\n\n3. Insert\n\n4. Update\n\n5. Delete\n\n6. Add\n\n7. Quit\n\nEnter your choice here: "))

            # This breaks the loop if the user followed the instructions
            if(FunctionChoice >= 1 or FunctionChoice <= 5):

                # This breaks the loop
                break

        # This makes sure the user put in an int and not a str
        except ValueError:

            # This prints out a result to the user
            print("\nERROR: Please enter one of the algorithm numbers!")

    # This checks if the user chose 1
    if (FunctionChoice == 1):

        # This calls the Search function
        Search()

     # This checks if the user chose 2
    elif(FunctionChoice == 2):

        # This calls the Sort function
        Sort()

     # This checks if the user chose 3
    elif(FunctionChoice == 3):

        # This calls the Insert function
        Insert()

     # This checks if the user chose 4
    elif(FunctionChoice == 4):

        # This calls the Update function
        Update()

     # This checks if the user chose 5
    elif(FunctionChoice == 5):

        # This calls the Delete function
        Delete()

     # This checks if the user chose 6
    elif(FunctionChoice == 6):

        # This calls the Add function
        Add()

    # This checks if the user chose 7
    elif(FunctionChoice == 7):

        # This loops to make sure the use input is valid before continuing
        while True:

            # This is to break the loop and end the program
            if(SaveChoice == "yes"):

            # This is to break the loop and end the program
                break

            # This asks the user if they want to import a file
            SaveChoice = (input("\nWould you like to save your data to a file? (yes/no): "))

            # This checks if the user inputs was a valid response. If not it prints an error and loops in order to ask again
            while SaveChoice != "yes" and SaveChoice != "no":

                # This prints out a result to the user and asks for input
                SaveChoice = (input("\nERROR: Please input: yes or no\n\nWould you like to save your data to a file? (yes/no): "))

                # If the user input is valid the loop is broken
                if SaveChoice == "yes" or SaveChoice == "no":
                    break

            # This allows the user to import a file if they said yes
            if SaveChoice == "yes":

                # This makes sure that the user input is valid
                while True:

                    # This allows the user to input a file in their directory to save to
                    FileNameTwo = (input("\nPlease enter the name of the file (ex. Data.txt): "))

                    # This tests to make sure the user input file name is in the directory
                    if(os.path.exists(FileNameTwo) == True):

                        # This creates a File variable to open and read the user's file
                        File = open(FileNameTwo, 'a')

                        # This writes to the file and is there to indicate and separate new data added to the file
                        File.write("New data points:\n")

                        # This loops through the data
                        for x in DataPoints:

                            # This writes the data to the file
                            File.write(str(x) + "\n")

                        # This closes the file
                        File.close()

                        # This tells the user their data will be saved
                        print("\nYour data will now be saved and added to your file")

                        # This breaks the loop
                        break

                    # This tests if the user input variable is not in the directory
                    elif(os.path.exists(FileNameTwo) == False):

                        # This prints out a result for the user
                        print("\nPlease enter a valid file name (It has to be in the same directory)")

            # This is to break the loop and end the program
            if (SaveChoice == "no"):

                # This breaks the loop to quit the program
                print("\nOkay! Nothing was saved")

                # This breaks the loop
                break

        # This is to break the loop and end the program
        if (SaveChoice == "no"):

           # This is to break the loop and end the program
            break

    # This is to break the loop and end the program
    if(SaveChoice == "yes"):

        # This is to break the loop and end the program
        break

    # This asks the user if they want to start over and assigns their answer to a variable if it's accepted
    ContinueTwo = input("\nWould you like to edit more data points? (yes/no): ")

    # This checks if the user inputs was a valid response. If not it prints an error and loops in order to ask again
    while ContinueTwo != "yes" and ContinueTwo != "no":

        # This prints out a result to the user and asks for input
        ContinueTwo = input("\nERROR: Please input: yes or no\n\nWould you like to edit more data points? (yes/no): ")

        # If the user input is valid the loop is broken
        if ContinueTwo == "yes" or ContinueTwo == "no":

            # This breaks the loop
            break

    # This ends the loop/program if the user input:'no'. However, if they had input yes the main loop/program restarts
    if ContinueTwo == "no":

        # This loops to make sure the use input is valid before continuing
        while True:

            # This breaks the loop to quit the program
            if(SaveChoice == "yes"):

                # This breaks the loop to quit the program
                break

            # This asks the user if they want to import a file
            SaveChoice = (input("\nWould you like to save your data to a file? (yes/no): "))

            # This checks if the user inputs was a valid response. If not it prints an error and loops in order to ask again
            while SaveChoice != "yes" and SaveChoice != "no":

                # This prints out a result to the user and asks for input
                SaveChoice = (input("\nERROR: Please input: yes or no\n\nWould you like to save your data to a file? (yes/no): "))

                # If the user input is valid the loop is broken
                if SaveChoice == "yes" or SaveChoice == "no":

                    # This breaks the loop
                    break

            # This allows the user to import a file if they said yes
            if SaveChoice == "yes":

                # This loops to make sure user input is valid
                while True:

                    # This accepts user input for a file name
                    FileNameTwo = (input("\nPlease enter the name of the file (ex. Data.txt): "))

                    # This checks if the user input file is in the directory 
                    if(os.path.exists(FileNameTwo) == True):

                        # This creates a File variable to open and read the user's file
                        File = open(FileNameTwo, 'a')

                        # This writes to the file and is there to indicate and separate new data added to the file
                        File.write("New data points:\n")

                        # This loops through the data
                        for x in DataPoints:

                            # This writes the data to the file with spaces
                            File.write(str(x) + "\n")

                        # This closes the file
                        File.close()

                        # This tells the user their data will be saved
                        print("\nYour data will now be saved and added to your file")

                        # This breaks the loop
                        break

                    # This checks if the user input file is not in the directory
                    elif(os.path.exists(FileNameTwo) == False):

                        # This prints out a result to the user
                        print("\nPlease enter a valid file name (It has to be in the same directory)")
            
            # This is to break the loop and quit the program
            if (SaveChoice == "no"):

                # This prints out a result to the user
                print("\nOkay! Nothing was saved")

                # This breaks the loop
                break