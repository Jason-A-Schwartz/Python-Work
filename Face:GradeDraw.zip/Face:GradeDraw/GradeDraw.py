# Jason Schwartz
# Bonus Assignment

# This imports all objects from the graphics library
from graphics import *

# This states what the program will do
print("This program will take user input and display an image based on how high they scored in the class")

# This collects user input and assigns it to a variable
UInputFinalGrade = int(input("Please enter your final course score: "))

# This tests if the input is within the allowed range
while UInputFinalGrade < 0 or UInputFinalGrade > 100:

    # This prints if the user did not put in an acceptable integer in the range
    print("Error, please enter within the range of: 0-100")

    # This asks for user input again
    UInputFinalGrade = int(input("Please enter your final course score: "))

# This tests if the return value is within an A range
if 100 >= UInputFinalGrade >= 89:

    # This uses the GraphWin class to creates a window for objects to be drawn which will be titled Face and be 400px X 400px
    win = GraphWin("Face", 400, 400)

    # This uses the setBackground method to change the color of the background
    win.setBackground("light blue")

    # This creates a rectangle object by defining a opposite corner points to determine the height and width
    Neck = Rectangle(Point(140, 330), Point(260, 400))

    # This uses the setFill method to change the inside color of the object
    Neck.setFill('beige')

    # This uses the draw method to actually draw the object in the GraphWin class window
    Neck.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarOne = Oval(Point(30, 140), Point(70, 224))

    # This uses the setFill method to change the inside color of the object
    EarOne.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarHoleOne = Oval(Point(40, 150), Point(60, 210))

    # This uses the setFill method to change the inside color of the object
    EarHoleOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarHoleOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarTwo = Oval(Point(370, 140), Point(330, 224))

    # This uses the setFill method to change the inside color of the object
    EarTwo.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarTwo.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarHoleTwo = Oval(Point(360, 150), Point(340, 210))

    # This uses the setFill method to change the inside color of the object
    EarHoleTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarHoleTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    Face = Circle(Point(200, 200), 150)

    # This uses the setFill method to change the inside color of the object
    Face.setFill('beige')

    # This uses the draw method to actually draw the object in the GraphWin class window
    Face.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Mouth = Oval(Point(100, 200), Point(300, 315))

    # This uses the setFill method to change the inside color of the object
    Mouth.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Mouth.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Smile = Oval(Point(100, 150), Point(301, 300))

    # This uses the setOutline method to change the outline color of the object
    Smile.setOutline('beige')

    # This uses the setFill method to change the inside color of the object
    Smile.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Smile.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Nose = Oval(Point(180, 230), Point(220, 200))

    # This uses the setFill method to change the inside color of the object
    Nose.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Nose.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    NostrilOne = Oval(Point(190, 224), Point(198, 230))

    # This uses the setFill method to change the inside color of the object
    NostrilOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    NostrilOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    NostrilTwo = Oval(Point(202, 224), Point(210, 230))

    # This uses the setFill method to change the inside color of the object
    NostrilTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    NostrilTwo.draw(win)

    # This creates a polygon object by defining points to determine the shape
    EyebrowOne = Polygon(Point(130, 90), Point(130, 115), Point(180, 120))

    # This uses the setFill method to change the inside color of the object
    EyebrowOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyebrowOne.draw(win)

    # This creates a circle object by defining a center point and the radius
    EyeOne = Circle(Point(150, 150), 20)

    # This uses the setFill method to change the inside color of the object
    EyeOne.setFill('white')

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyeOne.draw(win)

    # This creates a circle object by defining a center point and the radius
    PupilOne = Circle(Point(150, 150), 10)

    # This uses the setFill method to change the inside color of the object
    PupilOne.setFill('black')

    # This uses the draw method to actually draw the object in the GraphWin class window
    PupilOne.draw(win)

    # This creates a polygon object by defining points to determine the shape
    EyebrowTwo = Polygon(Point(230, 120), Point(280, 115), Point(280, 90))

    # This uses the setFill method to change the inside color of the object
    EyebrowTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyebrowTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    EyeTwo = Circle(Point(250, 150), 20)

    # This uses the setFill method to change the inside color of the object
    EyeTwo.setFill('white')

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyeTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    PupilTwo = Circle(Point(250, 150), 10)

    # This uses the setFill method to change the inside color of the object
    PupilTwo.setFill('black')

    # This uses the draw method to actually draw the object in the GraphWin class window
    PupilTwo.draw(win)

    # This uses the text object to display a message at the given point
    CloseText = Text(Point(200, 390), 'Click anywhere to quit.')

    # This uses the text object to display a message at the given point
    GradeText = Text(Point(200, 10), "Your final grade is an A")

    # This uses the draw method to actually draw the object in the GraphWin class window
    GradeText.draw(win)

    # This uses the draw method to actually draw the object in the GraphWin class window
    CloseText.draw(win)

    # This uses the getMouse object and pauses the code and waits for a user to click
    win.getMouse()

    # This uses the close object to officially end the code and close the window
    win.close()

# This tests if the return value is within a B range
elif 88 >= UInputFinalGrade >= 79:

    # This uses the GraphWin class to creates a window for objects to be drawn which will be titled Face and be 400px X 400px
    win = GraphWin("Face", 400, 400)

    # This uses the setBackground method to change the color of the background
    win.setBackground("light blue")

    # This creates a rectangle object by defining a opposite corner points to determine the height and width
    Neck = Rectangle(Point(140, 330), Point(260, 400))

    # This uses the setFill method to change the inside color of the object
    Neck.setFill('beige')

    # This uses the draw method to actually draw the object in the GraphWin class window
    Neck.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarOne = Oval(Point(30, 140), Point(70, 224))

    # This uses the setFill method to change the inside color of the object
    EarOne.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarHoleOne = Oval(Point(40, 150), Point(60, 210))

    # This uses the setFill method to change the inside color of the object
    EarHoleOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarHoleOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarTwo = Oval(Point(370, 140), Point(330, 224))

    # This uses the setFill method to change the inside color of the object
    EarTwo.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarTwo.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarHoleTwo = Oval(Point(360, 150), Point(340, 210))

    # This uses the setFill method to change the inside color of the object
    EarHoleTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarHoleTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    Face = Circle(Point(200, 200), 150)

    # This uses the setFill method to change the inside color of the object
    Face.setFill('beige')

    # This uses the draw method to actually draw the object in the GraphWin class window
    Face.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Mouth = Oval(Point(100, 200), Point(300, 315))

    # This uses the setFill method to change the inside color of the object
    Mouth.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Mouth.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Smile = Oval(Point(100, 150), Point(301, 300))

    # This uses the setOutline method to change the outline color of the object
    Smile.setOutline('beige')

    # This uses the setFill method to change the inside color of the object
    Smile.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Smile.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Nose = Oval(Point(180, 230), Point(220, 200))

    # This uses the setFill method to change the inside color of the object
    Nose.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Nose.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    NostrilOne = Oval(Point(190, 224), Point(198, 230))

    # This uses the setFill method to change the inside color of the object
    NostrilOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    NostrilOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    NostrilTwo = Oval(Point(202, 224), Point(210, 230))

    # This uses the setFill method to change the inside color of the object
    NostrilTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    NostrilTwo.draw(win)

    # This creates a polygon object by defining points to determine the shape
    EyebrowOne = Polygon(Point(130, 90), Point(130, 115), Point(180, 120))

    # This uses the setFill method to change the inside color of the object
    EyebrowOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyebrowOne.draw(win)

    # This creates a circle object by defining a center point and the radius
    EyeOne = Circle(Point(150, 150), 20)

    # This uses the setFill method to change the inside color of the object
    EyeOne.setFill('white')

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyeOne.draw(win)

    # This creates a circle object by defining a center point and the radius
    PupilOne = Circle(Point(150, 150), 10)

    # This uses the setFill method to change the inside color of the object
    PupilOne.setFill('black')

    # This uses the draw method to actually draw the object in the GraphWin class window
    PupilOne.draw(win)

    # This creates a polygon object by defining points to determine the shape
    EyebrowTwo = Polygon(Point(230, 120), Point(280, 115), Point(280, 90))

    # This uses the setFill method to change the inside color of the object
    EyebrowTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyebrowTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    EyeTwo = Circle(Point(250, 150), 20)

    # This uses the setFill method to change the inside color of the object
    EyeTwo.setFill('white')

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyeTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    PupilTwo = Circle(Point(250, 150), 10)

    # This uses the setFill method to change the inside color of the object
    PupilTwo.setFill('black')

    # This uses the draw method to actually draw the object in the GraphWin class window
    PupilTwo.draw(win)

    # This uses the text object to display a message at the given point
    GradeText = Text(Point(200, 10), "Your final grade is a B")

    # This uses the draw method to actually draw the object in the GraphWin class window
    GradeText.draw(win)

    # This uses the text object to display a message at the given point
    CloseText = Text(Point(200, 390), "Click anywhere to quit.")

    # This uses the draw method to actually draw the object in the GraphWin class window
    CloseText.draw(win)

    # This uses the getMouse object and pauses the code and waits for a user to click
    win.getMouse()

    # This uses the close object to officially end the code and close the window
    win.close()

# This tests if the return value is within a C range
elif 78 >= UInputFinalGrade >= 70:

    # This uses the GraphWin class to creates a window for objects to be drawn which will be titled Face and be 400px X 400px
    win = GraphWin("Face", 400, 400)

    # This uses the setBackground method to change the color of the background
    win.setBackground("light blue")

    # This creates a rectangle object by defining a opposite corner points to determine the height and width
    Neck = Rectangle(Point(140, 330), Point(260, 400))

    # This uses the setFill method to change the inside color of the object
    Neck.setFill('beige')

    # This uses the draw method to actually draw the object in the GraphWin class window
    Neck.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarOne = Oval(Point(30, 140), Point(70, 224))

    # This uses the setFill method to change the inside color of the object
    EarOne.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarHoleOne = Oval(Point(40, 150), Point(60, 210))

    # This uses the setFill method to change the inside color of the object
    EarHoleOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarHoleOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarTwo = Oval(Point(370, 140), Point(330, 224))

    # This uses the setFill method to change the inside color of the object
    EarTwo.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarTwo.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarHoleTwo = Oval(Point(360, 150), Point(340, 210))

    # This uses the setFill method to change the inside color of the object
    EarHoleTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarHoleTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    Face = Circle(Point(200, 200), 150)

    # This uses the setFill method to change the inside color of the object
    Face.setFill('beige')

    # This uses the draw method to actually draw the object in the GraphWin class window
    Face.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Mouth = Oval(Point(100, 250), Point(300, 320))

    # This uses the setFill method to change the inside color of the object
    Mouth.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Mouth.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Frown = Oval(Point(90, 270), Point(310, 320))

    # This uses the setOutline method to change the outline color of the object
    Frown.setOutline('beige')

    # This uses the setFill method to change the inside color of the object
    Frown.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Frown.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Nose = Oval(Point(180, 230), Point(220, 200))

    # This uses the setFill method to change the inside color of the object
    Nose.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Nose.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    NostrilOne = Oval(Point(190, 224), Point(198, 230))

    # This uses the setFill method to change the inside color of the object
    NostrilOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    NostrilOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    NostrilTwo = Oval(Point(202, 224), Point(210, 230))

    # This uses the setFill method to change the inside color of the object
    NostrilTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    NostrilTwo.draw(win)

    # This creates a polygon object by defining points to determine the shape
    EyebrowOne = Polygon(Point(130, 90), Point(130, 115), Point(180, 120))

    # This uses the setFill method to change the inside color of the object
    EyebrowOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyebrowOne.draw(win)

    # This creates a circle object by defining a center point and the radius
    EyeOne = Circle(Point(150, 150), 20)

    # This uses the setFill method to change the inside color of the object
    EyeOne.setFill('white')

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyeOne.draw(win)

    # This creates a circle object by defining a center point and the radius
    PupilOne = Circle(Point(150, 150), 10)

    # This uses the setFill method to change the inside color of the object
    PupilOne.setFill('black')

    # This uses the draw method to actually draw the object in the GraphWin class window
    PupilOne.draw(win)

    # This creates a polygon object by defining points to determine the shape
    EyebrowTwo = Polygon(Point(230, 120), Point(280, 115), Point(280, 90))

    # This uses the setFill method to change the inside color of the object
    EyebrowTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyebrowTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    EyeTwo = Circle(Point(250, 150), 20)

    # This uses the setFill method to change the inside color of the object
    EyeTwo.setFill('white')

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyeTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    PupilTwo = Circle(Point(250, 150), 10)

    # This uses the setFill method to change the inside color of the object
    PupilTwo.setFill('black')

    # This uses the draw method to actually draw the object in the GraphWin class window
    PupilTwo.draw(win)

    # This uses the text object to display a message at the given point
    GradeText = Text(Point(200, 10), "Your final grade is a C")

    # This uses the draw method to actually draw the object in the GraphWin class window
    GradeText.draw(win)

    # This uses the text object to display a message at the given point
    CloseText = Text(Point(200, 390), 'Click anywhere to quit.')

    # This uses the draw method to actually draw the object in the GraphWin class window
    CloseText.draw(win)

    # This uses the getMouse object and pauses the code and waits for a user to click
    win.getMouse()

    # This uses the close object to officially end the code and close the window
    win.close()

# This tests if the return value is within a D range
elif 69 >= UInputFinalGrade >= 60:

    # This uses the GraphWin class to creates a window for objects to be drawn which will be titled Face and be 400px X 400px
    win = GraphWin("Face", 400, 400)

    # This uses the setBackground method to change the color of the background
    win.setBackground("light blue")

    # This creates a rectangle object by defining a opposite corner points to determine the height and width
    Neck = Rectangle(Point(140, 330), Point(260, 400))

    # This uses the setFill method to change the inside color of the object
    Neck.setFill('beige')

    # This uses the draw method to actually draw the object in the GraphWin class window
    Neck.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarOne = Oval(Point(30, 140), Point(70, 224))

    # This uses the setFill method to change the inside color of the object
    EarOne.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarHoleOne = Oval(Point(40, 150), Point(60, 210))

    # This uses the setFill method to change the inside color of the object
    EarHoleOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarHoleOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarTwo = Oval(Point(370, 140), Point(330, 224))

    # This uses the setFill method to change the inside color of the object
    EarTwo.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarTwo.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarHoleTwo = Oval(Point(360, 150), Point(340, 210))

    # This uses the setFill method to change the inside color of the object
    EarHoleTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarHoleTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    Face = Circle(Point(200, 200), 150)

    # This uses the setFill method to change the inside color of the object
    Face.setFill('beige')

    # This uses the draw method to actually draw the object in the GraphWin class window
    Face.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Mouth = Oval(Point(100, 250), Point(300, 320))

    # This uses the setFill method to change the inside color of the object
    Mouth.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Mouth.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Frown = Oval(Point(90, 270), Point(310, 320))

    # This uses the setOutline method to change the outline color of the object
    Frown.setOutline('beige')

    # This uses the setFill method to change the inside color of the object
    Frown.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Frown.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Nose = Oval(Point(180, 230), Point(220, 200))

    # This uses the setFill method to change the inside color of the object
    Nose.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Nose.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    NostrilOne = Oval(Point(190, 224), Point(198, 230))

    # This uses the setFill method to change the inside color of the object
    NostrilOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    NostrilOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    NostrilTwo = Oval(Point(202, 224), Point(210, 230))

    # This uses the setFill method to change the inside color of the object
    NostrilTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    NostrilTwo.draw(win)

    # This creates a polygon object by defining points to determine the shape
    EyebrowOne = Polygon(Point(130, 90), Point(130, 115), Point(180, 120))

    # This uses the setFill method to change the inside color of the object
    EyebrowOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyebrowOne.draw(win)

    # This creates a circle object by defining a center point and the radius
    EyeOne = Circle(Point(150, 150), 20)

    # This uses the setFill method to change the inside color of the object
    EyeOne.setFill('white')

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyeOne.draw(win)

    # This creates a circle object by defining a center point and the radius
    PupilOne = Circle(Point(150, 150), 10)

    # This uses the setFill method to change the inside color of the object
    PupilOne.setFill('black')

    # This uses the draw method to actually draw the object in the GraphWin class window
    PupilOne.draw(win)

    # This creates a polygon object by defining points to determine the shape
    EyebrowTwo = Polygon(Point(230, 120), Point(280, 115), Point(280, 90))

    # This uses the setFill method to change the inside color of the object
    EyebrowTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyebrowTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    EyeTwo = Circle(Point(250, 150), 20)

    # This uses the setFill method to change the inside color of the object
    EyeTwo.setFill('white')

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyeTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    PupilTwo = Circle(Point(250, 150), 10)

    # This uses the setFill method to change the inside color of the object
    PupilTwo.setFill('black')

    # This uses the draw method to actually draw the object in the GraphWin class window
    PupilTwo.draw(win)

    # This uses the text object to display a message at the given point
    GradeText = Text(Point(200, 10), "Your final grade is a D")

    # This uses the draw method to actually draw the object in the GraphWin class window
    GradeText.draw(win)

    # This uses the text object to display a message at the given point
    CloseText = Text(Point(200, 390), 'Click anywhere to quit.')

    # This uses the draw method to actually draw the object in the GraphWin class window
    CloseText.draw(win)

    # This uses the getMouse object and pauses the code and waits for a user to click
    win.getMouse()

    # This uses the close object to officially end the code and close the window
    win.close()

# This tests if the return value is within a E range
elif 59 >= UInputFinalGrade >= 0:

    # This uses the GraphWin class to creates a window for objects to be drawn which will be titled Face and be 400px X 400px
    win = GraphWin("Face", 400, 400)

    # This uses the setBackground method to change the color of the background
    win.setBackground("light blue")

    # This creates a rectangle object by defining a opposite corner points to determine the height and width
    Neck = Rectangle(Point(140, 330), Point(260, 400))

    # This uses the setFill method to change the inside color of the object
    Neck.setFill('beige')

    # This uses the draw method to actually draw the object in the GraphWin class window
    Neck.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarOne = Oval(Point(30, 140), Point(70, 224))

    # This uses the setFill method to change the inside color of the object
    EarOne.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarHoleOne = Oval(Point(40, 150), Point(60, 210))

    # This uses the setFill method to change the inside color of the object
    EarHoleOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarHoleOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarTwo = Oval(Point(370, 140), Point(330, 224))

    # This uses the setFill method to change the inside color of the object
    EarTwo.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarTwo.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    EarHoleTwo = Oval(Point(360, 150), Point(340, 210))

    # This uses the setFill method to change the inside color of the object
    EarHoleTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EarHoleTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    Face = Circle(Point(200, 200), 150)

    # This uses the setFill method to change the inside color of the object
    Face.setFill('beige')

    # This uses the draw method to actually draw the object in the GraphWin class window
    Face.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Mouth = Oval(Point(100, 250), Point(300, 320))

    # This uses the setFill method to change the inside color of the object
    Mouth.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Mouth.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Frown = Oval(Point(90, 270), Point(310, 320))

    # This uses the setOutline method to change the outline color of the object
    Frown.setOutline('beige')

    # This uses the setFill method to change the inside color of the object
    Frown.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Frown.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    Nose = Oval(Point(180, 230), Point(220, 200))

    # This uses the setFill method to change the inside color of the object
    Nose.setFill("beige")

    # This uses the draw method to actually draw the object in the GraphWin class window
    Nose.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    NostrilOne = Oval(Point(190, 224), Point(198, 230))

    # This uses the setFill method to change the inside color of the object
    NostrilOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    NostrilOne.draw(win)

    # This creates an oval object by defining corner points to determine the height and witdth
    NostrilTwo = Oval(Point(202, 224), Point(210, 230))

    # This uses the setFill method to change the inside color of the object
    NostrilTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    NostrilTwo.draw(win)

    # This creates a polygon object by defining points to determine the shape
    EyebrowOne = Polygon(Point(130, 90), Point(130, 115), Point(180, 120))

    # This uses the setFill method to change the inside color of the object
    EyebrowOne.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyebrowOne.draw(win)

    # This creates a circle object by defining a center point and the radius
    EyeOne = Circle(Point(150, 150), 20)

    # This uses the setFill method to change the inside color of the object
    EyeOne.setFill('white')

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyeOne.draw(win)

    # This creates a circle object by defining a center point and the radius
    PupilOne = Circle(Point(150, 150), 10)

    # This uses the setFill method to change the inside color of the object
    PupilOne.setFill('black')

    # This uses the draw method to actually draw the object in the GraphWin class window
    PupilOne.draw(win)

    # This creates a polygon object by defining points to determine the shape
    EyebrowTwo = Polygon(Point(230, 120), Point(280, 115), Point(280, 90))

    # This uses the setFill method to change the inside color of the object
    EyebrowTwo.setFill("black")

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyebrowTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    EyeTwo = Circle(Point(250, 150), 20)

    # This uses the setFill method to change the inside color of the object
    EyeTwo.setFill('white')

    # This uses the draw method to actually draw the object in the GraphWin class window
    EyeTwo.draw(win)

    # This creates a circle object by defining a center point and the radius
    PupilTwo = Circle(Point(250, 150), 10)

    # This uses the setFill method to change the inside color of the object
    PupilTwo.setFill('black')

    # This uses the draw method to actually draw the object in the GraphWin class window
    PupilTwo.draw(win)

    # This uses the text object to display a message at the given point
    GradeText = Text(Point(200, 10), "Your final grade is an E")

    # This uses the draw method to actually draw the object in the GraphWin class window
    GradeText.draw(win)

    # This uses the text object to display a message at the given point
    CloseText = Text(Point(200, 390), 'Click anywhere to quit.')

    # This uses the draw method to actually draw the object in the GraphWin class window
    CloseText.draw(win)

    # This uses the getMouse object and pauses the code and waits for a user to click
    win.getMouse()

    # This uses the close object to officially end the code and close the window
    win.close()
