# Jason Schwartz
# CINF 308: Programing For Informatics Assignment Three

# This loops the program over and over again until the user decides they don't need it anymore
while True: 

    # This keeps track of how many guesses the user needed to get the right password
    GCounter = 1

    # These are variables set to format the PasswordGuesses.txt file correctly
    Counter = 0
    Reset = "Previous Guesses:"

    # This opens and resets the PasswordGuesses.txt file with the correct formatting. This is done by opening the file in write mode (clearing its contents),writing my info to it, and then closing it
    File = open('PasswordGuesses.txt', 'w')
    File.write(Reset)
    File.close()

    # This explains what the program will do
    print("\nThis program will:\n\n1) Open a .txt file (in the same directory) with possible passwords\n2) Allow the user to input guesses as to which password is the correct one\n3) Add the wrong guesses to another .txt file (in the same directory) for reference \n4) Read both .txt files again to help the user until they get it right\n5) Showcase how many guesses it took for the user to get it right\n6) Allow the user to restart the program or quit\n")

    # This opens the PossiblePasswords.txt file in read format and then reads it and closes it
    File = open('PossiblePasswords.txt','r')
    print(File.read(),"\n")
    File.close()

    # This loop keeps going until the user guesses the correct password
    while True:

        # This if elif statement tests if it is the first time the loop is running. If it is, it just asks for input. If it isn't, it opens/reads/closes the PossiblePasswords.txt file and the PasswordGuesses.txt file. After that it asks the user to guess again
        if Counter == 0:
            PasswordGuess = input("Please guess what the correct password is based off of the list from above (format matters!): ")
        elif Counter != 0:
            File = open('PossiblePasswords.txt', 'r')
            print(File.read(), "\n")
            File.close()
            File = open('PasswordGuesses.txt', 'r')
            print(File.read(), "\n")
            File.close()
            PasswordGuess = input("Please guess what the correct password is based off of the list from above (format matters!): ")

        # This if elif statement tests the user input to see if they guess the right number. If they do, it displays the final message with how many guesses it took and breaks the loop (it is also grammatically correct). However, if they do not get it right the counters increase and the guess is appended to the PasswordGuesses.txt file with proper formatting
        if PasswordGuess == "bungiecord33" and GCounter == 1:
            print("\nYou guessed correctly! And it only took you",GCounter,"attempt")
            break
        elif PasswordGuess == "bungiecord33" and GCounter != 1:
            print("\nYou guessed correctly! And it only took you",GCounter, "attempts")
            break
        else:
            print("\nSorry, that password is incorrect but it has been stored for your reference!\n")

            # This increases the counters
            Counter = Counter + 1
            GCounter = GCounter + 1

            # This variable is set to correctly format the appended information to the PasswordGuesses.txt file
            FileAdd = ("\n"+ str(Counter) + ". " + PasswordGuess)

            # This actually appends the information with the correct format to the PaswordGuesses.txt file and then closes it
            File = open('PasswordGuesses.txt', 'a')
            File.write(FileAdd)
            File.close()

    # This asks the user if they want to start over and assigns their answer to a variable if it is accepted
    StartOver = input("\n5) Start Over? (yes/no): ")

    # This checks if the user inputs was a valid response. If not it prints an error and loops in order to ask again. If it is valid it breaks the loop
    while StartOver != "yes" and StartOver != "no":
        StartOver = input(
            "\nERROR: Please input: yes or no\n\nStart Over? (yes/no): ")
        if StartOver == "yes" or StartOver == "no":
            break

    # This ends the loop/program if the user input:'no'. However, if they input yes the main loop/program restarts
    if StartOver == "no":
        break