# Jason Schwartz
# CINF 308: Programing For Informatics Assignment Eleven

# This imports the string module to be called later
import string

# This imports the random module to be called later
import random

# This is a function to call a random word from the histogram based off the instructions
def choose_from_hist():

    # This prints out a message for the user
    print("\nThis is a random word from the .txt file:\n")

    # This uses the random import module to pull a random word from the dictionary keys
    print(random.choice(list(Histogram.keys())))

# This creates a dictionary to be used as a histogram
Histogram = {}

# This creates a count for later
Count = 0

# This explains what the program will do
print("\nThis program will display a bunch of information about different words in a .txt file")

# This opens the text file in read mode
File = open("CHICavalryCurt.txt","r")

# This reads the file and assigns its data to the Text variable
Text = File.read()

# This creates the Punctuation variable and assigns it the string punctuation format. However, it also accounts for some weird character syntax errors I had with my .txt file
Punctuation = string.punctuation + "’" + "”" + "“"

# This loop removes the punctuation from the text file by replacing found values with nothing
for x in Punctuation:
    Text = Text.replace(x, "")

# This loop splits the data into their own lines while getting rid of extra blank spaces and converting it to lowercase. It also assigns the data to the dictionary
for x in Text.split():

    # This replaces the spaces with nothing
    x = x.replace(" ", "")

    # This makes the text lowercase
    x = x.lower()

    # This assigns the data to the dictionary keys and values and then goes up by one to continue down the line
    Histogram[x] = Histogram.get(x, 0) + 1

# This prints all the words used in the text file by grabbing the dictionary values
print("\nThe total number of words in the story are: " + str(sum(Histogram.values())))

# This prints out a message for the user
print("\nThese are how many times each word was used:")

# This prints how many times each word was used in the text file by grabbing the dictionary keys and values and displaying them
for x in Histogram:
    print("\n" + str(x) + ": " + str(Histogram[x]))

# This prints prints how many different words were used by using the length of the dictionary values
print("\nThe number of different words are: " + str(len(Histogram)) + "\n")

# This prints a message for the user
print("This is the story without these words:\n")

# This creates a list for later
WordList = ["one","chapter","of","end"]

# This prints out the values in the list
for x in WordList:
    print(str(WordList[Count]) + "\n")
    Count = Count + 1

# This resets the count
Count = 0

# This converts the text to lowercase and then checks for the words in the list to replace them with nothing
for x in WordList:

    # This converts the Text to lowercase
    Text = Text.casefold()

    # This replaces each list value with nothing so it is removed from the list
    Text = Text.replace(WordList[Count], "")

    # This progresses the list in the search
    Count = Count + 1

# Thiss loop prints out the new Text with the removed words
for x in Text.split():
    x = x.lower()
    print(x)

# This calls the function I created earlier
choose_from_hist()